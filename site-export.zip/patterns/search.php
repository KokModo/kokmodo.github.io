<?php
/**
 * Title: Search
 * Slug: spiel/search
 * Inserter: no
 */

declare( strict_types = 1 );
?>

<!-- wp:search {"showLabel":false,"placeholder":"<?php echo esc_html_x( 'Search...', 'This is a placeholder text in a search field', 'spiel' ); ?>","buttonPosition":"button-inside","buttonUseIcon":true} /-->
