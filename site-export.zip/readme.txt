=== Spiel ===
Contributors: Automattic
Requires at least: 6.0
Tested up to: 6.4
Requires PHP: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Spiel is a game magazine theme.

== Changelog ==

= 1.0.3 =
* Spiel: Edit readme (#7554)

= 1.0.2 =
* Revert Remove undeployed version of Spiel

= 1.0.1 =
* Remove undeployed version of Spiel
* Spiel: re-add and fix translator comment

= 1.0.0 =
* Initial release

== Copyright ==

Spiel is based on Tenku (https://wordpress.com/theme/tenku/), (C) Automattic, [GPLv2 or later](http://www.gnu.org/licenses/gpl-2.0.html)

Tenku WordPress Theme, (C) 2023
Tenku is distributed under the terms of the GNU GPL.
Tenku is based on Tenku (), (C) , [GPLv2 or later](http://www.gnu.org/licenses/gpl-2.0.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

This theme bundles the following third-party resources:

All the images seen on the screenshot.png were generated with AI using Midjourney and DALL-E.

Orbitron Font
Copyright 2018 The Orbitron Project Authors (https://github.com/theleagueof/orbitron), with Reserved Font Name: "Orbitron". 
This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is available with a FAQ at: http://scripts.sil.org/OFL 
License URL: http://scripts.sil.org/OFL 
Source: https://www.theleagueofmoveabletype.com/
-- End of Orbitron Font credits --

Manrope Font
Copyright 2019 The Manrope Project Authors (https://github.com/cssobral2013/manrope)
This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is available with a FAQ at: http://scripts.sil.org/OFL 
License URL: http://scripts.sil.org/OFL 
Source: http://gent.media
-- End of Manrope Font credits --
